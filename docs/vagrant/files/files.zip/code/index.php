<?php

echo 'Hello!';
