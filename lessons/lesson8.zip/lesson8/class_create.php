<?php

class MyFirstClass
{
    public $someProp;

    function myMethod()
    {
        echo 'Hello!';
    }
}
